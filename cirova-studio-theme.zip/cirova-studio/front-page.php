<?php
/**
 * Front Page (homepage) template
 */
header('Content-Type: text/html; charset=UTF-8');
readfile(get_template_directory() . '/home.html');
exit;
