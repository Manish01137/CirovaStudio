<?php
add_action( 'after_setup_theme', function() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
} );
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
add_action( 'template_redirect', function() {
    if ( is_404() ) {
        status_header( 200 );
        include get_template_directory() . '/index.php';
        exit;
    }
} );
