<?php
header( 'Content-Type: text/html; charset=UTF-8' );
readfile( get_template_directory() . '/smm-services.html' );
exit;
