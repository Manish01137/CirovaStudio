<?php
/**
 * Cirova Studio - URL Router
 * Maps URL paths to HTML files. Works regardless of WordPress page setup.
 */

$theme = get_template_directory();
$path  = trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );

// Strip WP subdir prefix if installed in subfolder
$home_path = trim( parse_url( home_url(), PHP_URL_PATH ), '/' );
if ( $home_path && strpos( $path, $home_path ) === 0 ) {
    $path = trim( substr( $path, strlen( $home_path ) ), '/' );
}

$routes = array(
    ''                              => 'home.html',
    'home'                          => 'home.html',
    'about'                         => 'about.html',
    'about-us'                      => 'about.html',
    'about-cirova-studio'           => 'about.html',
    'contact'                       => 'contact.html',
    'contact-us'                    => 'contact.html',
    'video-editing-services'        => 'video-editing-services.html',
    'video-editing'                 => 'video-editing-services.html',
    'smm-services'                  => 'smm-services.html',
    'smm'                           => 'smm-services.html',
    'social-media-management'       => 'smm-services.html',
    'website-development'           => 'website-development.html',
    'web-development'               => 'website-development.html',
    'ppc-services'                  => 'ppc-services.html',
    'ppc'                           => 'ppc-services.html',
    'digital-marketing-services'    => 'digital-marketing-services.html',
    'digital-marketing'             => 'digital-marketing-services.html',
    // Catch the legacy single "services" path
    'services'                      => 'video-editing-services.html',
);

$file = isset( $routes[ $path ] ) ? $routes[ $path ] : 'home.html';
$full = $theme . '/' . $file;

if ( ! file_exists( $full ) ) {
    $full = $theme . '/home.html';
}

header( 'Content-Type: text/html; charset=UTF-8' );
readfile( $full );
exit;
