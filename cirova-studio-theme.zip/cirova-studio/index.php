<?php
/**
 * Fallback template - shows homepage if anyone hits an unmapped path.
 */
header('Content-Type: text/html; charset=UTF-8');
readfile(get_template_directory() . '/home.html');
exit;
