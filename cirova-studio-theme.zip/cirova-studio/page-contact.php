<?php
/**
 * Contact Page template (slug: contact)
 */
header('Content-Type: text/html; charset=UTF-8');
readfile(get_template_directory() . '/contact.html');
exit;
