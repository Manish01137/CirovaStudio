<?php
header( 'Content-Type: text/html; charset=UTF-8' );
readfile( get_template_directory() . '/website-development.html' );
exit;
